## 8.68.0 (2026-08-24)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.68.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.67.0 (2026-08-10)

### 🚀 Features

- **typescript-eslint:** export basic globs for using tseslint ([#12105](https://github.com/typescript-eslint/typescript-eslint/pull/12105))

### ❤️ Thank You

- Claude Sonnet 5
- Evyatar Daud @StyleShit
- Josh Goldberg
- Josh Goldberg ✨
- Kirk Waiblinger @kirkwaiblinger

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.67.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.66.0 (2026-08-03)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.66.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.65.0 (2026-07-20)

### 🚀 Features

- add warning when TS 7 is detected ([#12529](https://github.com/typescript-eslint/typescript-eslint/pull/12529))

### ❤️ Thank You

- Josh Goldberg ✨
- Kirk Waiblinger @kirkwaiblinger

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.65.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.64.0 (2026-07-13)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.64.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.63.0 (2026-07-06)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.63.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.62.1 (2026-06-29)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.62.1) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.62.0 (2026-06-22)

### 🚀 Features

- remove redundant package.json "files" ([#12444](https://github.com/typescript-eslint/typescript-eslint/pull/12444))

### ❤️ Thank You

- Kirk Waiblinger @kirkwaiblinger

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.62.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.61.1 (2026-06-15)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.61.1) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.61.0 (2026-06-08)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.61.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.60.1 (2026-06-01)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.60.1) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.60.0 (2026-05-25)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.60.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.59.4 (2026-05-18)

### 🩹 Fixes

- **typescript-eslint:** export Compatible* types from typescript-eslint to resolve pnpm TS error ([#12340](https://github.com/typescript-eslint/typescript-eslint/pull/12340))

### ❤️ Thank You

- Kirk Waiblinger @kirkwaiblinger

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.59.4) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.59.3 (2026-05-11)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.59.3) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.59.2 (2026-05-04)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.59.2) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.59.1 (2026-04-27)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.59.1) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.59.0 (2026-04-20)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.59.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.58.2 (2026-04-13)

### 🩹 Fixes

- remove tsbuildinfo cache file from published packages ([#12187](https://github.com/typescript-eslint/typescript-eslint/pull/12187))

### ❤️ Thank You

- Abhijeet Singh @cseas

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.58.2) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.58.1 (2026-04-08)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.58.1) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.58.0 (2026-03-30)

### 🚀 Features

- support TypeScript 6 ([#12124](https://github.com/typescript-eslint/typescript-eslint/pull/12124))

### ❤️ Thank You

- Evyatar Daud @StyleShit

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.58.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.57.2 (2026-03-23)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.57.2) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.57.1 (2026-03-16)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.57.1) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.57.0 (2026-03-09)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.57.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.56.1 (2026-02-23)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.56.1) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.56.0 (2026-02-16)

### 🚀 Features

- support ESLint v10 ([#12057](https://github.com/typescript-eslint/typescript-eslint/pull/12057))

### ❤️ Thank You

- Brad Zacher @bradzacher
- Joshua Chen

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.56.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.55.0 (2026-02-09)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

See [GitHub Releases](https://github.com/typescript-eslint/typescript-eslint/releases/tag/v8.55.0) for more information.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.54.0 (2026-01-26)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.53.1 (2026-01-19)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.53.0 (2026-01-12)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.52.0 (2026-01-05)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.51.0 (2025-12-29)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.50.1 (2025-12-22)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.50.0 (2025-12-15)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.49.0 (2025-12-08)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.48.1 (2025-12-02)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.48.0 (2025-11-24)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.47.0 (2025-11-17)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.46.4 (2025-11-10)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.46.3 (2025-11-03)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.46.2 (2025-10-20)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.46.1 (2025-10-13)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.46.0 (2025-10-06)

### 🚀 Features

- **typescript-eslint:** export util types ([#10848](https://github.com/typescript-eslint/typescript-eslint/pull/10848), [#10849](https://github.com/typescript-eslint/typescript-eslint/pull/10849))

### ❤️ Thank You

- Mister-Hope @Mister-Hope

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.45.0 (2025-09-29)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.44.1 (2025-09-22)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.44.0 (2025-09-15)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.43.0 (2025-09-08)

### 🩹 Fixes

- **eslint-plugin:** [no-deprecated] should report deprecated exports and reexports ([#11359](https://github.com/typescript-eslint/typescript-eslint/pull/11359))

### ❤️ Thank You

- Victor Genaev @mainframev

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.42.0 (2025-09-02)

### 🚀 Features

- deprecate tseslint.config() ([#11531](https://github.com/typescript-eslint/typescript-eslint/pull/11531))

### 🩹 Fixes

- **typescript-eslint:** handle non-normalized windows paths produced by jiti ([#11546](https://github.com/typescript-eslint/typescript-eslint/pull/11546))

### ❤️ Thank You

- Kirk Waiblinger @kirkwaiblinger

You can read about our [versioning strategy](https://typescript-eslint.io/users/versioning) and [releases](https://typescript-eslint.io/users/releases) on our website.

## 8.41.0 (2025-08-25)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.40.0 (2025-08-18)

### 🩹 Fixes

- **typescript-eslint:** export `plugin`, `parser`, and `configs` that are compatible with both `defineConfig()` and `tseslint.config()` ([#11475](https://github.com/typescript-eslint/typescript-eslint/pull/11475))

### ❤️ Thank You

- Kirk Waiblinger @kirkwaiblinger

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.39.1 (2025-08-11)

### 🩹 Fixes

- **typescript-eslint:** handle `file://` urls in stack trace when inferring `tsconfigRootDir` ([#11464](https://github.com/typescript-eslint/typescript-eslint/pull/11464))

### ❤️ Thank You

- Kirk Waiblinger @kirkwaiblinger

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.39.0 (2025-08-04)

### 🚀 Features

- update to TypeScript 5.9.2 ([#11445](https://github.com/typescript-eslint/typescript-eslint/pull/11445))

### ❤️ Thank You

- Brad Zacher @bradzacher

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.38.0 (2025-07-21)

### 🩹 Fixes

- **typescript-eslint:** error on nested `extends` in `tseslint.config()` ([#11361](https://github.com/typescript-eslint/typescript-eslint/pull/11361))
- **typescript-eslint:** infer tsconfigRootDir with v8 API ([#11412](https://github.com/typescript-eslint/typescript-eslint/pull/11412))

### ❤️ Thank You

- Kirk Waiblinger @kirkwaiblinger

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.37.0 (2025-07-14)

### 🚀 Features

- **typescript-estree:** infer tsconfigRootDir from call stack ([#11370](https://github.com/typescript-eslint/typescript-eslint/pull/11370))

### ❤️ Thank You

- Josh Goldberg ✨

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.36.0 (2025-07-07)

### 🚀 Features

- **typescript-eslint:** support `basePath` in `tseslint.config()` ([#11357](https://github.com/typescript-eslint/typescript-eslint/pull/11357))

### ❤️ Thank You

- Kirk Waiblinger @kirkwaiblinger

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.35.1 (2025-06-30)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.35.0 (2025-06-23)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.34.1 (2025-06-16)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.34.0 (2025-06-09)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.33.1 (2025-06-02)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.33.0 (2025-05-26)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.32.1 (2025-05-12)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.32.0 (2025-05-05)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.31.1 (2025-04-28)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.31.0 (2025-04-21)

### 🩹 Fixes

- **typescript-eslint:** gracefully handle invalid flat config objects in config helper ([#11070](https://github.com/typescript-eslint/typescript-eslint/pull/11070))
- **typescript-eslint:** address bugs in `config()` around global ignores ([#11065](https://github.com/typescript-eslint/typescript-eslint/pull/11065))

### ❤️ Thank You

- Kirk Waiblinger @kirkwaiblinger

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.30.1 (2025-04-14)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.30.0 (2025-04-14)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.29.1 (2025-04-07)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.29.0 (2025-03-31)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.28.0 (2025-03-24)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.27.0 (2025-03-17)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.26.1 (2025-03-10)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.26.0 (2025-03-03)

### 🚀 Features

- support TypeScript 5.8 ([#10903](https://github.com/typescript-eslint/typescript-eslint/pull/10903))

### ❤️ Thank You

- Dirk Luijk @dirkluijk

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.25.0 (2025-02-24)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.24.1 (2025-02-17)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.24.0 (2025-02-10)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.23.0 (2025-02-03)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.22.0 (2025-01-27)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.21.0 (2025-01-20)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.20.0 (2025-01-13)

### 🚀 Features

- **eslint-plugin:** [no-misused-spread] add new rule ([#10551](https://github.com/typescript-eslint/typescript-eslint/pull/10551))

### ❤️ Thank You

- Josh Goldberg ✨

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.19.1 (2025-01-06)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.19.0 (2024-12-30)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.18.2 (2024-12-23)

### 🩹 Fixes

- **typescript-eslint:** export types so that declarations can be named for dts files ([#10513](https://github.com/typescript-eslint/typescript-eslint/pull/10513))

### ❤️ Thank You

- Brad Zacher @bradzacher

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.18.1 (2024-12-16)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.18.0 (2024-12-09)

### 🩹 Fixes

- typescript peer dependency ([#10373](https://github.com/typescript-eslint/typescript-eslint/pull/10373))

### ❤️  Thank You

- rtritto

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.17.0 (2024-12-02)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.16.0 (2024-11-25)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.15.0 (2024-11-18)

### 🚀 Features

- **typescript-eslint:** allow infinitely deep array nesting in config function and extends ([#10333](https://github.com/typescript-eslint/typescript-eslint/pull/10333))
- **eslint-plugin:** new rule `no-unsafe-type-assertion` ([#10051](https://github.com/typescript-eslint/typescript-eslint/pull/10051))
- **eslint-plugin:** added related-getter-setter-pairs rule ([#10192](https://github.com/typescript-eslint/typescript-eslint/pull/10192))

### 🩹 Fixes

- add missing peer dependencies ([#9744](https://github.com/typescript-eslint/typescript-eslint/pull/9744))

### ❤️  Thank You

- Brad Zacher @bradzacher
- Ethan Wu
- Josh Goldberg ✨
- Ronen Amiel

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.14.0 (2024-11-11)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.13.0 (2024-11-04)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.12.2 (2024-10-29)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.12.1 (2024-10-28)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.12.0 (2024-10-28)

### 🚀 Features

- **typescript-eslint:** improve undefined extension handling ([#10177](https://github.com/typescript-eslint/typescript-eslint/pull/10177))

### ❤️  Thank You

- Maxim Stykow @mstykow

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.11.0 (2024-10-21)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.10.0 (2024-10-17)

### 🩹 Fixes

- **typescript-eslint:** propagate `name` field to extended configs in `config` helper ([#10094](https://github.com/typescript-eslint/typescript-eslint/pull/10094))

### ❤️  Thank You

- auvred @auvred

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.9.0 (2024-10-14)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.8.1 (2024-10-07)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.8.0 (2024-09-30)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.7.0 (2024-09-23)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.6.0 (2024-09-16)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.5.0 (2024-09-09)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.4.0 (2024-09-02)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.3.0 (2024-08-26)


### 🚀 Features

- **eslint-plugin:** [no-deprecation] add rule


### ❤️  Thank You

- Abraham Guo
- Daichi Kamiyama
- Josh Goldberg ✨
- Kim Sang Du
- Sukka
- Vida Xie

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.2.0 (2024-08-19)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.1.0 (2024-08-12)


### 🚀 Features

- **typescript-eslint:** add JSDoc comments on generated configs


### ❤️  Thank You

- Aly Thobani
- Brad Zacher
- James
- Josh Goldberg ✨
- Joshua Chen
- Olivier Zalmanski
- YeonJuan
- Yukihiro Hasegawa

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 8.0.1 (2024-08-05)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

# 8.0.0 (2024-07-31)


### 🚀 Features

- **eslint-plugin:** deprecate no-loss-of-precision extension rule

- **utils:** allow specifying additional rule meta.docs in RuleCreator

- **eslint-plugin:** split no-empty-object-type out from ban-types and no-empty-interfaces

- **typescript-estree:** stabilize EXPERIMENTAL_useProjectService as projectService

- **eslint-plugin:** remove deprecated no-throw-literal rule

- **eslint-plugin:** apply initial config changes for v8

- **eslint-plugin:** remove no-useless-template-literals

- **eslint-plugin:** replace ban-types with no-restricted-types, no-unsafe-function-type, no-wrapper-object-types

- **eslint-plugin:** [no-unnecessary-type-parameters] promote to strict


### 🩹 Fixes

- disable `projectService` in `disabled-type-checked` shared config

- **eslint-plugin:** correct rules.d.ts types to not rely on non-existent imports


### ❤️  Thank You

- Abraham Guo
- Alfred Ringstad
- auvred
- Brad Zacher
- Christopher Aubut
- Collin Bachman
- James Henry
- Josh Goldberg
- Josh Goldberg ✨
- Kirk Waiblinger
- StyleShit
- Victor Lin
- Yukihiro Hasegawa

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.18.0 (2024-07-29)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.17.0 (2024-07-22)


### 🚀 Features

- **eslint-plugin:** backport no-unsafe-function type, no-wrapper-object-types from v8 to v7


### ❤️  Thank You

- Armano
- Josh Goldberg ✨
- Kirk Waiblinger
- StyleShit

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.16.1 (2024-07-15)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.16.0 (2024-07-08)


### 🚀 Features

- **eslint-plugin:** [no-unnecessary-parameter-property-assignment] add new rule


### 🩹 Fixes

- **deps:** update dependency @eslint-community/regexpp to v4.11.0

- **website:** react key error on internal pages of website


### ❤️  Thank You

- Abraham Guo
- auvred
- Josh Goldberg ✨
- Juan Sanchez
- Vinccool96
- YeonJuan
- Yukihiro Hasegawa

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.15.0 (2024-07-01)


### 🚀 Features

- **eslint-plugin:** back-port new rules around empty object types from v8


### 🩹 Fixes

- disable `EXPERIMENTAL_useProjectService` in `disabled-type-checked` shared config


### ❤️  Thank You

- auvred
- Kim Sang Du
- rgehbt
- Vinccool96

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.14.1 (2024-06-24)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.14.0 (2024-06-24)


### 🚀 Features

- support TypeScript 5.5


### ❤️  Thank You

- Brad Zacher
- cm-ayf
- Jake Bailey
- James Zhan
- Joshua Chen
- yoshi2no

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.13.1 (2024-06-17)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.13.0 (2024-06-10)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.12.0 (2024-06-03)


### 🚀 Features

- **eslint-plugin:** [no-useless-template-literals] rename to `no-useless-template-expression` (deprecate `no-useless-template-literals`)


### 🩹 Fixes

- no-useless-template-expression -> no-unnecessary-template-expression


### ❤️  Thank You

- Abraham Guo
- Han Yeong-woo
- Joshua Chen
- Kim Sang Du
- Kirk Waiblinger
- YeonJuan

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.11.0 (2024-05-27)


### 🚀 Features

- **eslint-plugin:** deprecate prefer-ts-expect-error in favor of ban-ts-comment


### ❤️  Thank You

- Abraham Guo
- auvred
- Dom Armstrong
- Kirk Waiblinger

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.10.0 (2024-05-20)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.9.0 (2024-05-13)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.8.0 (2024-04-29)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.7.1 (2024-04-22)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.7.0 (2024-04-15)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.6.0 (2024-04-08)


### 🚀 Features

- add `name` field to shared configs and flat config types

- bump npm dependency ranges


### ❤️  Thank You

- Abraham Guo
- auvred
- Brad Zacher

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.5.0 (2024-04-01)


### 🩹 Fixes

- **typescript-eslint:** improve support for legacy configs


### ❤️  Thank You

- Brad Zacher
- Kim Sang Du
- Mark de Dios
- Naru
- YeonJuan

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.4.0 (2024-03-25)


### 🚀 Features

- **eslint-plugin:** deprecate no-throw-literal and add a renamed only-throw-error


### 🩹 Fixes

- **typescript-eslint:** declare peer dependency on `utils` to ensure npm correctly installs dependencies


### ❤️  Thank You

- Abraham Guo
- Brad Zacher
- Josh Goldberg ✨
- Kim Sang Du
- Kirk Waiblinger
- Marco Pasqualetti
- YeonJuan

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.3.1 (2024-03-18)


### 🩹 Fixes

- **eslint-plugin:** [no-floating-promises] revert disable of ignoreVoid in strict config


### ❤️  Thank You

- Josh Goldberg ✨

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.3.0 (2024-03-18)


### 🚀 Features

- **eslint-plugin:** add meta.docs.recommended setting for strict config options

- **eslint-plugin:** add rule `use-unknown-in-catch-callback-variables`


### 🩹 Fixes

- correct `engines.node` constraints in `package.json`


### ❤️  Thank You

- Abraham Guo
- Alexu
- Arka Pratim Chaudhuri
- auvred
- Derrick Isaacson
- fnx
- Josh Goldberg ✨
- Kirk Waiblinger
- Marta Cardoso
- Michaël De Boey
- Tristan Rasmussen
- YeonJuan

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.2.0 (2024-03-11)


### 🚀 Features

- support TS 5.4


### 🩹 Fixes

- **eslint-plugin:** expose *-type-checked-only configs for extension

- **typescript-eslint:** set `sourceType: "module"` in base shared config

- **typescript-eslint:** export `ConfigWithExtends` type


### ❤️  Thank You

- Arka Pratim Chaudhuri
- auvred
- Chris Plummer
- Fotis Papadogeorgopoulos
- Josh Goldberg ✨
- Kirk Waiblinger
- Wayne Zhang
- YeonJuan

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.1.1 (2024-03-04)


### 🩹 Fixes

- **typescript-eslint:** apply `ignores` to all extended configs passed to `config` helper function


### ❤️  Thank You

- auvred

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.1.0 (2024-02-26)


### 🚀 Features

- **eslint-plugin:** add *-type-checked-only configs


### ❤️  Thank You

- Arka Pratim Chaudhuri
- Josh Goldberg ✨
- YeonJuan

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.0.2 (2024-02-19)


### 🩹 Fixes

- fix tsconfig-less check errors, fix `@types/eslint` incompatibilities, add tests


### ❤️  Thank You

- Brad Zacher
- Gareth Jones

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 7.0.1 (2024-02-12)

This was a version bump only for typescript-eslint to align it with other projects, there were no code changes.

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

# 7.0.0 (2024-02-12)


### 🚀 Features

- ⚠️  bump ESLint, NodeJS, and TS minimum version requirements

- add support for flat configs


#### ⚠️  Breaking Changes

- ⚠️  bump ESLint, NodeJS, and TS minimum version requirements

### ❤️  Thank You

- Brad Zacher
- Kirk Waiblinger
- StyleShit
- YeonJuan

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.

## 6.21.0 (2024-02-05)


### 🚀 Features

- allow `parserOptions.project: false`


### ❤️  Thank You

- auvred
- Brad Zacher
- Kirk Waiblinger
- Pete Gonzalez
- YeonJuan

You can read about our [versioning strategy](https://main--typescript-eslint.netlify.app/users/versioning) and [releases](https://main--typescript-eslint.netlify.app/users/releases) on our website.